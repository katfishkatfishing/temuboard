.build/obj_temuboard_default/platforms/timer.o: platforms/timer.c \
 keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h platforms/timer.h platforms/chibios/_timer.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
platforms/timer.h:
platforms/chibios/_timer.h:
