.build/obj_temuboard_default/platforms/chibios/syscall-fallbacks.o: \
 platforms/chibios/syscall-fallbacks.c keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h platforms/chibios/errno.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
platforms/chibios/errno.h:
