.build/obj_temuboard_default/platforms/synchronization_util.o: \
 platforms/synchronization_util.c keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h platforms/synchronization_util.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
platforms/synchronization_util.h:
