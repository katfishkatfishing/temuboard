.build/obj_temuboard_default/protocol/usb_device_state.o: \
 tmk_core/protocol/usb_device_state.c keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h tmk_core/protocol/usb_device_state.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
tmk_core/protocol/usb_device_state.h:
