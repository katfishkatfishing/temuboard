.build/obj_temuboard_default/qmk_fnv_type_validation.o: \
 lib/fnv/qmk_fnv_type_validation.c keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h lib/fnv/fnv.h lib/fnv/longlong.h \
 quantum/compiler_support.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
lib/fnv/fnv.h:
lib/fnv/longlong.h:
quantum/compiler_support.h:
