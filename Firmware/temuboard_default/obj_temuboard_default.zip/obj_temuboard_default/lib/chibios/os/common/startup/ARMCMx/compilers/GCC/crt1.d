.build/obj_temuboard_default/lib/chibios/os/common/startup/ARMCMx/compilers/GCC/crt1.o: \
 lib/chibios/os/common/startup/ARMCMx/compilers/GCC/crt1.c \
 keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h \
 lib/chibios/os/common/startup/ARMCMx/devices/STM32F4xx/cmparams.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/board.h \
 lib/chibios/os/hal/boards/ST_STM32F4_DISCOVERY/board.h \
 lib/chibios/os/common/ext/ST/STM32F4xx/stm32f4xx.h \
 lib/chibios/os/common/ext/ST/STM32F4xx/stm32f405xx.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h \
 lib/chibios/os/common/ext/ST/STM32F4xx/system_stm32f4xx.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
lib/chibios/os/common/startup/ARMCMx/devices/STM32F4xx/cmparams.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/board.h:
lib/chibios/os/hal/boards/ST_STM32F4_DISCOVERY/board.h:
lib/chibios/os/common/ext/ST/STM32F4xx/stm32f4xx.h:
lib/chibios/os/common/ext/ST/STM32F4xx/stm32f405xx.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h:
lib/chibios/os/common/ext/ST/STM32F4xx/system_stm32f4xx.h:
