generated-files: $(wildcard /k/temuboard/info.json)

generated-files: $(wildcard /k/temuboard/keyboard.json)

generated-files: $(wildcard /k/temuboard/rules.mk)

generated-files: $(wildcard /k/temuboard/post_rules.mk)

generated-files: $(wildcard /k/temuboard/config.h)

generated-files: $(wildcard /k/temuboard/post_config.h)

generated-files: $(wildcard /c/Users/hjone/qmk_firmware/keyboards/temuboard/keymaps/default/keymap.json)

generated-files: $(wildcard /c/Users/hjone/qmk_firmware/keyboards/temuboard/keymaps/default/info.json)

generated-files: $(wildcard /c/Users/hjone/qmk_firmware/keyboards/temuboard/keymaps/default/keyboard.json)

generated-files: $(wildcard /c/Users/hjone/qmk_firmware/keyboards/temuboard/keymaps/default/rules.mk)

generated-files: $(wildcard /c/Users/hjone/qmk_firmware/keyboards/temuboard/keymaps/default/post_rules.mk)

generated-files: $(wildcard /c/Users/hjone/qmk_firmware/keyboards/temuboard/keymaps/default/config.h)

generated-files: $(wildcard /c/Users/hjone/qmk_firmware/keyboards/temuboard/keymaps/default/post_config.h)

generated-files: $(wildcard /u/default/info.json)

generated-files: $(wildcard /u/default/keyboard.json)

generated-files: $(wildcard /u/default/rules.mk)

generated-files: $(wildcard /u/default/post_rules.mk)

generated-files: $(wildcard /u/default/config.h)

generated-files: $(wildcard /u/default/post_config.h)

