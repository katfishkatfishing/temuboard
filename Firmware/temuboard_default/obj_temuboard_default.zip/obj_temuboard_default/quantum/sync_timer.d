.build/obj_temuboard_default/quantum/sync_timer.o: quantum/sync_timer.c \
 keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h quantum/sync_timer.h platforms/timer.h \
 platforms/chibios/_timer.h quantum/keyboard.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
quantum/sync_timer.h:
platforms/timer.h:
platforms/chibios/_timer.h:
quantum/keyboard.h:
