.build/obj_temuboard_default/quantum/bitwise.o: quantum/bitwise.c \
 keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h quantum/util.h quantum/bits.h \
 quantum/bitwise.h platforms/chibios/_util.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
quantum/util.h:
quantum/bits.h:
quantum/bitwise.h:
platforms/chibios/_util.h:
