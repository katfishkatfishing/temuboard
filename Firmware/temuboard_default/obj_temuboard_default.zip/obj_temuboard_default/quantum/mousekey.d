.build/obj_temuboard_default/quantum/mousekey.o: quantum/mousekey.c \
 keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h quantum/keycode.h quantum/keycodes.h \
 quantum/modifiers.h tmk_core/protocol/host.h tmk_core/protocol/report.h \
 quantum/util.h quantum/bits.h quantum/bitwise.h \
 platforms/chibios/_util.h tmk_core/protocol/host_driver.h quantum/led.h \
 platforms/timer.h platforms/chibios/_timer.h quantum/logging/print.h \
 quantum/logging/sendchar.h platforms/progmem.h quantum/logging/debug.h \
 quantum/mousekey.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
quantum/keycode.h:
quantum/keycodes.h:
quantum/modifiers.h:
tmk_core/protocol/host.h:
tmk_core/protocol/report.h:
quantum/util.h:
quantum/bits.h:
quantum/bitwise.h:
platforms/chibios/_util.h:
tmk_core/protocol/host_driver.h:
quantum/led.h:
platforms/timer.h:
platforms/chibios/_timer.h:
quantum/logging/print.h:
quantum/logging/sendchar.h:
platforms/progmem.h:
quantum/logging/debug.h:
quantum/mousekey.h:
