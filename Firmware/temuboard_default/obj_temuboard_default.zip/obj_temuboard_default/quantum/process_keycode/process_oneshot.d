.build/obj_temuboard_default/quantum/process_keycode/process_oneshot.o: \
 quantum/process_keycode/process_oneshot.c keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h quantum/process_keycode/process_oneshot.h \
 quantum/action.h platforms/progmem.h quantum/keyboard.h \
 platforms/timer.h platforms/chibios/_timer.h quantum/keycode.h \
 quantum/keycodes.h quantum/modifiers.h quantum/action_code.h \
 quantum/action_util.h quantum/compiler_support.h \
 tmk_core/protocol/report.h quantum/util.h quantum/bits.h \
 quantum/bitwise.h platforms/chibios/_util.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
quantum/process_keycode/process_oneshot.h:
quantum/action.h:
platforms/progmem.h:
quantum/keyboard.h:
platforms/timer.h:
platforms/chibios/_timer.h:
quantum/keycode.h:
quantum/keycodes.h:
quantum/modifiers.h:
quantum/action_code.h:
quantum/action_util.h:
quantum/compiler_support.h:
tmk_core/protocol/report.h:
quantum/util.h:
quantum/bits.h:
quantum/bitwise.h:
platforms/chibios/_util.h:
