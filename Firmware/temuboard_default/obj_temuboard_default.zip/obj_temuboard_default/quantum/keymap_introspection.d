.build/obj_temuboard_default/quantum/keymap_introspection.o: \
 quantum/keymap_introspection.c keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h keyboards/temuboard/keymaps/default/keymap.c \
 .build/obj_temuboard_default/src/default_keyboard.h quantum/quantum.h \
 platforms/chibios/platform_deps.h lib/chibios/os/hal/include/hal.h \
 lib/chibios/os/common/portability/GCC/ccportab.h \
 lib/chibios/os/hal/osal/rt-nil/osal.h lib/chibios/os/rt/include/ch.h \
 lib/chibios/os/license/chlicense.h lib/chibios/os/license/chversion.h \
 lib/chibios/os/license/chcustomer.h \
 platforms/chibios/boards/common/configs/chconf.h \
 lib/chibios/os/rt/include/chchecks.h \
 lib/chibios/os/rt/include/chrestrictions.h \
 lib/chibios/os/rt/include/chearly.h \
 lib/chibios/os/common/ports/ARM-common/chtypes.h \
 lib/chibios/os/rt/include/chrfcu.h lib/chibios/os/rt/include/chdebug.h \
 lib/chibios/os/rt/include/chtime.h lib/chibios/os/rt/include/chlists.h \
 lib/chibios/os/rt/include/chalign.h lib/chibios/os/rt/include/chtrace.h \
 lib/chibios/os/rt/include/chport.h \
 lib/chibios/os/common/ports/ARMv7-M/chcore.h \
 lib/chibios/os/common/startup/ARMCMx/devices/STM32F4xx/cmparams.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/board.h \
 lib/chibios/os/hal/boards/ST_STM32F4_DISCOVERY/board.h \
 lib/chibios/os/common/ext/ST/STM32F4xx/stm32f4xx.h \
 lib/chibios/os/common/ext/ST/STM32F4xx/stm32f405xx.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h \
 lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h \
 lib/chibios/os/common/ext/ST/STM32F4xx/system_stm32f4xx.h \
 lib/chibios/os/common/ports/ARMv7-M/mpu.h \
 lib/chibios/os/hal/osal/rt-nil/chcore_timer.h \
 lib/chibios/os/rt/include/chtm.h lib/chibios/os/rt/include/chstats.h \
 lib/chibios/os/rt/include/chobjects.h lib/chibios/os/rt/include/chsys.h \
 lib/chibios/os/rt/include/chinstances.h lib/chibios/os/rt/include/chvt.h \
 lib/chibios/os/rt/include/chschd.h lib/chibios/os/rt/include/chthreads.h \
 lib/chibios/os/rt/include/chregistry.h lib/chibios/os/rt/include/chsem.h \
 lib/chibios/os/rt/include/chmtx.h lib/chibios/os/rt/include/chcond.h \
 lib/chibios/os/rt/include/chevents.h lib/chibios/os/rt/include/chmsg.h \
 lib/chibios/os/oslib/include/chlib.h \
 lib/chibios/os/oslib/include/chbsem.h \
 lib/chibios/os/oslib/include/chmboxes.h \
 lib/chibios/os/oslib/include/chmemcore.h \
 lib/chibios/os/oslib/include/chmemheaps.h \
 lib/chibios/os/oslib/include/chmempools.h \
 lib/chibios/os/oslib/include/chobjfifos.h \
 lib/chibios/os/oslib/include/chpipes.h \
 lib/chibios/os/oslib/include/chobjcaches.h \
 lib/chibios/os/oslib/include/chdelegates.h \
 lib/chibios/os/oslib/include/chjobs.h \
 lib/chibios/os/oslib/include/chfactory.h \
 lib/chibios/os/rt/include/chdynamic.h \
 platforms/chibios/boards/common/configs/halconf.h \
 keyboards/temuboard/mcuconf.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/mcuconf.h \
 lib/chibios/os/hal/ports/STM32/STM32F4xx/hal_lld.h \
 lib/chibios/os/hal/ports/STM32/STM32F4xx/stm32_registry.h \
 lib/chibios/os/hal/ports/STM32/STM32F4xx/hal_lld_type1.h \
 lib/chibios/os/hal/ports/common/ARMCMx/nvic.h \
 lib/chibios/os/hal/ports/common/ARMCMx/cache.h \
 lib/chibios/os/hal/ports/common/ARMCMx/mpu_v7m.h \
 lib/chibios/os/hal/ports/STM32/STM32F4xx/stm32_isr.h \
 lib/chibios/os/hal/ports/STM32/LLD/DMAv2/stm32_dma.h \
 lib/chibios/os/hal/ports/STM32/LLD/EXTIv1/stm32_exti.h \
 lib/chibios/os/hal/ports/STM32/STM32F4xx/stm32_rcc.h \
 lib/chibios/os/hal/ports/STM32/LLD/TIMv1/stm32_tim.h \
 lib/chibios/os/hal/include/hal_objects.h \
 lib/chibios/os/hal/include/hal_streams.h \
 lib/chibios/os/hal/include/hal_channels.h \
 lib/chibios/os/hal/include/hal_files.h \
 lib/chibios/os/hal/include/hal_ioblock.h \
 lib/chibios/os/hal/include/hal_mmcsd.h \
 lib/chibios/os/hal/include/hal_persistent.h \
 lib/chibios/os/hal/include/hal_flash.h \
 lib/chibios/os/hal/include/hal_safety.h \
 lib/chibios/os/hal/include/hal_buffers.h \
 lib/chibios/os/hal/include/hal_queues.h \
 lib/chibios/os/hal/include/hal_buffered_serial.h \
 lib/chibios/os/hal/include/hal_pal.h \
 lib/chibios/os/hal/ports/STM32/LLD/GPIOv2/hal_pal_lld.h \
 lib/chibios/os/hal/ports/STM32/LLD/GPIOv2/stm32_gpio.h \
 lib/chibios/os/hal/include/hal_adc.h \
 lib/chibios/os/hal/include/hal_can.h \
 lib/chibios/os/hal/include/hal_crypto.h \
 lib/chibios/os/hal/include/hal_dac.h \
 lib/chibios/os/hal/include/hal_efl.h \
 lib/chibios/os/hal/ports/STM32/STM32F4xx/hal_efl_lld.h \
 lib/chibios/os/hal/include/hal_gpt.h \
 lib/chibios/os/hal/include/hal_i2c.h \
 lib/chibios/os/hal/ports/STM32/LLD/I2Cv1/hal_i2c_lld.h \
 lib/chibios/os/hal/include/hal_i2s.h \
 lib/chibios/os/hal/include/hal_icu.h \
 lib/chibios/os/hal/include/hal_mac.h \
 lib/chibios/os/hal/include/hal_pwm.h \
 lib/chibios/os/hal/include/hal_rtc.h \
 lib/chibios/os/hal/include/hal_serial.h \
 lib/chibios/os/hal/include/hal_sdc.h \
 lib/chibios/os/hal/include/hal_sio.h \
 lib/chibios/os/hal/include/hal_spi.h \
 lib/chibios/os/hal/include/hal_trng.h \
 lib/chibios/os/hal/include/hal_uart.h \
 lib/chibios/os/hal/include/hal_usb.h \
 lib/chibios/os/hal/ports/STM32/LLD/OTGv1/hal_usb_lld.h \
 lib/chibios/os/hal/ports/STM32/LLD/OTGv1/stm32_otg.h \
 lib/chibios/os/hal/include/hal_wdg.h \
 lib/chibios/os/hal/include/hal_wspi.h \
 lib/chibios/os/hal/include/hal_st.h \
 lib/chibios/os/hal/ports/STM32/LLD/SYSTICKv1/hal_st_lld.h \
 lib/chibios/os/hal/include/hal_mmc_spi.h \
 lib/chibios/os/hal/include/hal_serial_usb.h \
 platforms/chibios/chibios_config.h quantum/compiler_support.h \
 platforms/wait.h platforms/chibios/_wait.h platforms/chibios/_wait.c \
 quantum/matrix.h platforms/gpio.h platforms/pin_defs.h \
 platforms/chibios/_pin_defs.h platforms/chibios/gpio.h \
 quantum/keyboard.h platforms/timer.h platforms/chibios/_timer.h \
 quantum/keymap_common.h quantum/quantum_keycodes.h quantum/keycodes.h \
 quantum/keymap_extras/keymap_us.h quantum/sequencer/sequencer.h \
 quantum/quantum_keycodes_legacy.h quantum/keycode_config.h \
 quantum/compiler_support.h quantum/eeconfig.h quantum/action_layer.h \
 quantum/action.h platforms/progmem.h quantum/keycode.h \
 quantum/modifiers.h quantum/action_code.h quantum/bitwise.h \
 quantum/keycode_string.h platforms/bootloader.h quantum/sync_timer.h \
 platforms/atomic_util.h platforms/chibios/atomic_util.h \
 tmk_core/protocol/host.h tmk_core/protocol/report.h quantum/util.h \
 quantum/bits.h platforms/chibios/_util.h tmk_core/protocol/host_driver.h \
 quantum/led.h quantum/action_util.h quantum/action_tapping.h \
 quantum/logging/print.h quantum/logging/sendchar.h \
 quantum/logging/debug.h platforms/suspend.h \
 quantum/bootmagic/bootmagic.h \
 quantum/process_keycode/process_key_override.h \
 quantum/process_keycode/process_space_cadet.h \
 quantum/send_string/send_string.h \
 quantum/send_string/send_string_keycodes.h drivers/oled/oled_driver.h \
 quantum/encoder.h quantum/mousekey.h quantum/keymap_introspection.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
keyboards/temuboard/keymaps/default/keymap.c:
.build/obj_temuboard_default/src/default_keyboard.h:
quantum/quantum.h:
platforms/chibios/platform_deps.h:
lib/chibios/os/hal/include/hal.h:
lib/chibios/os/common/portability/GCC/ccportab.h:
lib/chibios/os/hal/osal/rt-nil/osal.h:
lib/chibios/os/rt/include/ch.h:
lib/chibios/os/license/chlicense.h:
lib/chibios/os/license/chversion.h:
lib/chibios/os/license/chcustomer.h:
platforms/chibios/boards/common/configs/chconf.h:
lib/chibios/os/rt/include/chchecks.h:
lib/chibios/os/rt/include/chrestrictions.h:
lib/chibios/os/rt/include/chearly.h:
lib/chibios/os/common/ports/ARM-common/chtypes.h:
lib/chibios/os/rt/include/chrfcu.h:
lib/chibios/os/rt/include/chdebug.h:
lib/chibios/os/rt/include/chtime.h:
lib/chibios/os/rt/include/chlists.h:
lib/chibios/os/rt/include/chalign.h:
lib/chibios/os/rt/include/chtrace.h:
lib/chibios/os/rt/include/chport.h:
lib/chibios/os/common/ports/ARMv7-M/chcore.h:
lib/chibios/os/common/startup/ARMCMx/devices/STM32F4xx/cmparams.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/board.h:
lib/chibios/os/hal/boards/ST_STM32F4_DISCOVERY/board.h:
lib/chibios/os/common/ext/ST/STM32F4xx/stm32f4xx.h:
lib/chibios/os/common/ext/ST/STM32F4xx/stm32f405xx.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h:
lib/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h:
lib/chibios/os/common/ext/ST/STM32F4xx/system_stm32f4xx.h:
lib/chibios/os/common/ports/ARMv7-M/mpu.h:
lib/chibios/os/hal/osal/rt-nil/chcore_timer.h:
lib/chibios/os/rt/include/chtm.h:
lib/chibios/os/rt/include/chstats.h:
lib/chibios/os/rt/include/chobjects.h:
lib/chibios/os/rt/include/chsys.h:
lib/chibios/os/rt/include/chinstances.h:
lib/chibios/os/rt/include/chvt.h:
lib/chibios/os/rt/include/chschd.h:
lib/chibios/os/rt/include/chthreads.h:
lib/chibios/os/rt/include/chregistry.h:
lib/chibios/os/rt/include/chsem.h:
lib/chibios/os/rt/include/chmtx.h:
lib/chibios/os/rt/include/chcond.h:
lib/chibios/os/rt/include/chevents.h:
lib/chibios/os/rt/include/chmsg.h:
lib/chibios/os/oslib/include/chlib.h:
lib/chibios/os/oslib/include/chbsem.h:
lib/chibios/os/oslib/include/chmboxes.h:
lib/chibios/os/oslib/include/chmemcore.h:
lib/chibios/os/oslib/include/chmemheaps.h:
lib/chibios/os/oslib/include/chmempools.h:
lib/chibios/os/oslib/include/chobjfifos.h:
lib/chibios/os/oslib/include/chpipes.h:
lib/chibios/os/oslib/include/chobjcaches.h:
lib/chibios/os/oslib/include/chdelegates.h:
lib/chibios/os/oslib/include/chjobs.h:
lib/chibios/os/oslib/include/chfactory.h:
lib/chibios/os/rt/include/chdynamic.h:
platforms/chibios/boards/common/configs/halconf.h:
keyboards/temuboard/mcuconf.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/mcuconf.h:
lib/chibios/os/hal/ports/STM32/STM32F4xx/hal_lld.h:
lib/chibios/os/hal/ports/STM32/STM32F4xx/stm32_registry.h:
lib/chibios/os/hal/ports/STM32/STM32F4xx/hal_lld_type1.h:
lib/chibios/os/hal/ports/common/ARMCMx/nvic.h:
lib/chibios/os/hal/ports/common/ARMCMx/cache.h:
lib/chibios/os/hal/ports/common/ARMCMx/mpu_v7m.h:
lib/chibios/os/hal/ports/STM32/STM32F4xx/stm32_isr.h:
lib/chibios/os/hal/ports/STM32/LLD/DMAv2/stm32_dma.h:
lib/chibios/os/hal/ports/STM32/LLD/EXTIv1/stm32_exti.h:
lib/chibios/os/hal/ports/STM32/STM32F4xx/stm32_rcc.h:
lib/chibios/os/hal/ports/STM32/LLD/TIMv1/stm32_tim.h:
lib/chibios/os/hal/include/hal_objects.h:
lib/chibios/os/hal/include/hal_streams.h:
lib/chibios/os/hal/include/hal_channels.h:
lib/chibios/os/hal/include/hal_files.h:
lib/chibios/os/hal/include/hal_ioblock.h:
lib/chibios/os/hal/include/hal_mmcsd.h:
lib/chibios/os/hal/include/hal_persistent.h:
lib/chibios/os/hal/include/hal_flash.h:
lib/chibios/os/hal/include/hal_safety.h:
lib/chibios/os/hal/include/hal_buffers.h:
lib/chibios/os/hal/include/hal_queues.h:
lib/chibios/os/hal/include/hal_buffered_serial.h:
lib/chibios/os/hal/include/hal_pal.h:
lib/chibios/os/hal/ports/STM32/LLD/GPIOv2/hal_pal_lld.h:
lib/chibios/os/hal/ports/STM32/LLD/GPIOv2/stm32_gpio.h:
lib/chibios/os/hal/include/hal_adc.h:
lib/chibios/os/hal/include/hal_can.h:
lib/chibios/os/hal/include/hal_crypto.h:
lib/chibios/os/hal/include/hal_dac.h:
lib/chibios/os/hal/include/hal_efl.h:
lib/chibios/os/hal/ports/STM32/STM32F4xx/hal_efl_lld.h:
lib/chibios/os/hal/include/hal_gpt.h:
lib/chibios/os/hal/include/hal_i2c.h:
lib/chibios/os/hal/ports/STM32/LLD/I2Cv1/hal_i2c_lld.h:
lib/chibios/os/hal/include/hal_i2s.h:
lib/chibios/os/hal/include/hal_icu.h:
lib/chibios/os/hal/include/hal_mac.h:
lib/chibios/os/hal/include/hal_pwm.h:
lib/chibios/os/hal/include/hal_rtc.h:
lib/chibios/os/hal/include/hal_serial.h:
lib/chibios/os/hal/include/hal_sdc.h:
lib/chibios/os/hal/include/hal_sio.h:
lib/chibios/os/hal/include/hal_spi.h:
lib/chibios/os/hal/include/hal_trng.h:
lib/chibios/os/hal/include/hal_uart.h:
lib/chibios/os/hal/include/hal_usb.h:
lib/chibios/os/hal/ports/STM32/LLD/OTGv1/hal_usb_lld.h:
lib/chibios/os/hal/ports/STM32/LLD/OTGv1/stm32_otg.h:
lib/chibios/os/hal/include/hal_wdg.h:
lib/chibios/os/hal/include/hal_wspi.h:
lib/chibios/os/hal/include/hal_st.h:
lib/chibios/os/hal/ports/STM32/LLD/SYSTICKv1/hal_st_lld.h:
lib/chibios/os/hal/include/hal_mmc_spi.h:
lib/chibios/os/hal/include/hal_serial_usb.h:
platforms/chibios/chibios_config.h:
quantum/compiler_support.h:
platforms/wait.h:
platforms/chibios/_wait.h:
platforms/chibios/_wait.c:
quantum/matrix.h:
platforms/gpio.h:
platforms/pin_defs.h:
platforms/chibios/_pin_defs.h:
platforms/chibios/gpio.h:
quantum/keyboard.h:
platforms/timer.h:
platforms/chibios/_timer.h:
quantum/keymap_common.h:
quantum/quantum_keycodes.h:
quantum/keycodes.h:
quantum/keymap_extras/keymap_us.h:
quantum/sequencer/sequencer.h:
quantum/quantum_keycodes_legacy.h:
quantum/keycode_config.h:
quantum/compiler_support.h:
quantum/eeconfig.h:
quantum/action_layer.h:
quantum/action.h:
platforms/progmem.h:
quantum/keycode.h:
quantum/modifiers.h:
quantum/action_code.h:
quantum/bitwise.h:
quantum/keycode_string.h:
platforms/bootloader.h:
quantum/sync_timer.h:
platforms/atomic_util.h:
platforms/chibios/atomic_util.h:
tmk_core/protocol/host.h:
tmk_core/protocol/report.h:
quantum/util.h:
quantum/bits.h:
platforms/chibios/_util.h:
tmk_core/protocol/host_driver.h:
quantum/led.h:
quantum/action_util.h:
quantum/action_tapping.h:
quantum/logging/print.h:
quantum/logging/sendchar.h:
quantum/logging/debug.h:
platforms/suspend.h:
quantum/bootmagic/bootmagic.h:
quantum/process_keycode/process_key_override.h:
quantum/process_keycode/process_space_cadet.h:
quantum/send_string/send_string.h:
quantum/send_string/send_string_keycodes.h:
drivers/oled/oled_driver.h:
quantum/encoder.h:
quantum/mousekey.h:
quantum/keymap_introspection.h:
