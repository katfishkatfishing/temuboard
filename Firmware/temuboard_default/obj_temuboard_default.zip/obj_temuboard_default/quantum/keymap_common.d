.build/obj_temuboard_default/quantum/keymap_common.o: \
 quantum/keymap_common.c keyboards/temuboard/config.h \
 .build/obj_temuboard_default/src/info_config.h \
 platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h \
 platforms/chibios/config.h quantum/keymap_common.h quantum/keyboard.h \
 platforms/timer.h platforms/chibios/_timer.h \
 quantum/keymap_introspection.h tmk_core/protocol/report.h \
 quantum/keycode.h quantum/keycodes.h quantum/modifiers.h quantum/util.h \
 quantum/bits.h quantum/bitwise.h platforms/chibios/_util.h \
 quantum/action_layer.h quantum/action.h platforms/progmem.h \
 quantum/action_code.h quantum/logging/debug.h quantum/logging/print.h \
 quantum/logging/sendchar.h quantum/keycode_config.h \
 quantum/compiler_support.h quantum/eeconfig.h quantum/quantum_keycodes.h \
 quantum/keymap_extras/keymap_us.h quantum/sequencer/sequencer.h \
 quantum/quantum_keycodes_legacy.h
keyboards/temuboard/config.h:
.build/obj_temuboard_default/src/info_config.h:
platforms/chibios/boards/GENERIC_STM32_F405XG/configs/config.h:
platforms/chibios/config.h:
quantum/keymap_common.h:
quantum/keyboard.h:
platforms/timer.h:
platforms/chibios/_timer.h:
quantum/keymap_introspection.h:
tmk_core/protocol/report.h:
quantum/keycode.h:
quantum/keycodes.h:
quantum/modifiers.h:
quantum/util.h:
quantum/bits.h:
quantum/bitwise.h:
platforms/chibios/_util.h:
quantum/action_layer.h:
quantum/action.h:
platforms/progmem.h:
quantum/action_code.h:
quantum/logging/debug.h:
quantum/logging/print.h:
quantum/logging/sendchar.h:
quantum/keycode_config.h:
quantum/compiler_support.h:
quantum/eeconfig.h:
quantum/quantum_keycodes.h:
quantum/keymap_extras/keymap_us.h:
quantum/sequencer/sequencer.h:
quantum/quantum_keycodes_legacy.h:
